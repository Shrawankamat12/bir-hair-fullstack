import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
plugins: [react()],

// Admin application is served under /admin
base: '/admin/',

server: {
port: 5174,
},

build: {
outDir: 'dist',
assetsDir: 'assets',
},
});
