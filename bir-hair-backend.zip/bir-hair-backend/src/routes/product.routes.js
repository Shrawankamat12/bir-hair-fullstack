const router = require('express').Router();
const { getProducts, getProduct, getProductsByBadge } = require('../controllers/product.controller');

router.get('/', getProducts);
router.get('/badge/:badge', getProductsByBadge);
router.get('/:idOrSlug', getProduct);

module.exports = router;
